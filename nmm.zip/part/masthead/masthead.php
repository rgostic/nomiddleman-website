<header class="masthead-wrapper">
    <div class="masthead">
        <h1><?php echo $post->post_title; ?></h1>
    </div>
</header>