<?php  ?>
        <footer class="site-footer">
            <div class="row footer-bottom">
                <div class="columns centered align-self-middle">
                    <p class="footer-copyright">© Nomiddleman Crypto, 2019. All Rights Reserved.</p>
                </div>
            </div>
        </footer>
        <?php wp_footer(); ?>
    </body>
</html>