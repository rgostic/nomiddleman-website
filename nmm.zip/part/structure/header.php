<header class="site-header">
        <div class="site-logo">
            <a href="<?php echo home_url('/'); ?>">

                <img src="<?php echo OM_DIR . '/img/svg/NEWLOGO.svg'; ?>" alt="Nomiddleman Crypto Logo">
            </a>
        </div>
</header>