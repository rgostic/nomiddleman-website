<?php
?>
<div class="cta-wrapper">
    <div>
        <h4>Get it now</h4>
        <p>Download our plugin today</p>
    </div>
    <a class="button-gradient" href="https://wordpress.org/plugins/nomiddleman-crypto-payments-for-woocommerce/">Get it now</a>
</div>
