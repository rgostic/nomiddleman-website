<?php
?>
<div class="social-list">
    <ul>
        <li><a href="https://www.instagram.com/ompacific/">
            <span class="dashicons dashicons-instagram"></span>
        </a></li>
        <li><a href="https://www.facebook.com/ompacific1/">
            <span class="dashicons dashicons-facebook-alt"></span>
        </a></li>
        <li><a href="https://twitter.com/om_pacific">
            <span class="dashicons dashicons-twitter"></span>
        </a></li>
    </ul>
</div>
