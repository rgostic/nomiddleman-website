<?php
?>

            <div class="feature-wrapper">
                <h3>Features</h3>
                <div class="feature-items-wrapper">
                    <div class="feature-item-wrapper">
                        <h5>Automatic payment processing</h5>
                        <p>Updates the order to Paid after transaction confirmation</p>
                    </div>
                    <div class="feature-item-wrapper">
                        <h5>Real Time Crypto Valuation</h5>
                        <p>We retrieve real time pricing information for every order</p>
                    </div>
                    <div class="feature-item-wrapper">
                        <h5>Privacy Mode</h5>
                        <p>Privacy mode generates a unique address for every order</p>
                    </div>
                    <div class="feature-item-wrapper">
                        <h5>Customer QR Code</h5>
                        <p>Fully automated QR code</p>
                    </div>
                    <div class="feature-item-wrapper">
                        <h5>Multi-Fiat Support</h5>
                        <p>We support all Woocommerce Fiat Currencies (USD, EUR, CAD, etc..)</p>
                    </div>
                </div>
            </div>
