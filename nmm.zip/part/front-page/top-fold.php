<?php
?>

<div class="top-fold">
    <h1>WooCommerce Bitcoin and Cryptocurrency Payment Gateway</h1>
    <div class="container fluid">
        <div class="row">
            <div class="columns large-offset-5">
        <p>No Fees</p>
        <p>No Registration</p>
        <p>No Logins</p>
        <p>No Middleman</p>
                </div>
            </div>
    </div>
</div>


