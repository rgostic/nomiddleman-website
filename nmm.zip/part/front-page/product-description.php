<?php
?>

<div class="description-wrapper">
    <h2>Crypto E-Commerce, The Right Way</h2>
    <p>With blockchain technology, E-Commerce is easy. Other payment gateways over-engineer their product to get in the middle. We keep things simple and private, leaving you in control.</p>
</div>
