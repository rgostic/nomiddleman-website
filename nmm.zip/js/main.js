// jQuery(function($){
//     $(window).scroll(function() {
//         var scroll = $(window).scrollTop(); // how many pixels you've scrolled
//         var height = $(window).height();
//         var total_height = $(document).height();
//         console.log(scroll + ' + ' + height + ' = ' + total_height );
//         if(scroll > 0){
//             $('.scroll-nav').addClass('solid-through');
//             $('.site-logo img').addClass('see-through');
//         } else {
//             $('.scroll-nav').removeClass('solid-through');
//             $('.site-logo img').removeClass('see-through');
//         }
//         if (scroll + height > total_height - 0.5) {
//             $('.site-logo img').removeClass('see-through');
//         }
//
//     });
// })(jQuery);
