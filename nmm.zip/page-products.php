<?php
get_template_part('part/structure/head');
get_template_part('part/structure/header');
get_template_part('part/masthead/masthead');
get_template_part('part/products/lab-results');
get_template_part('part/general/contact-form');
get_template_part('part/structure/footer');